# QuickChat - High-Level Design (HLD)

## 1. System Overview

QuickChat is a real-time messaging application built on a client-server architecture using WebSocket for bidirectional communication. The system enables users to send instant messages in private and group conversations with persistent storage in MongoDB.

## 2. Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                        Client Layer                          │
│  ┌────────────────────────────────────────────────────┐    │
│  │  Web Browser (Chrome, Firefox, Safari, Edge)       │    │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────┐ │    │
│  │  │   HTML/CSS   │  │  JavaScript  │  │   DOM    │ │    │
│  │  │              │  │  (App Logic) │  │          │ │    │
│  │  └──────────────┘  └──────────────┘  └──────────┘ │    │
│  └────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
                            │
                            │ HTTP/HTTPS (REST API)
                            │ WebSocket (Real-time)
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                     Application Server                       │
│  ┌────────────────────────────────────────────────────┐    │
│  │              Node.js + Express.js                   │    │
│  │  ┌──────────────────────────────────────────────┐  │    │
│  │  │            REST API Layer                     │  │    │
│  │  │  - /api/auth/register                        │  │    │
│  │  │  - /api/auth/login                           │  │    │
│  │  │  - /api/users                                │  │    │
│  │  └──────────────────────────────────────────────┘  │    │
│  │  ┌──────────────────────────────────────────────┐  │    │
│  │  │         WebSocket Server (ws)                 │  │    │
│  │  │  - Connection Management                      │  │    │
│  │  │  - Message Broadcasting                       │  │    │
│  │  │  - Event Handling                             │  │    │
│  │  └──────────────────────────────────────────────┘  │    │
│  └────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
                            │
                            │ MongoDB Driver
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                    Business Logic Layer                      │
│  ┌──────────────┐  ┌──────────────┐  ┌────────────────┐   │
│  │   User       │  │    Chat      │  │    Message     │   │
│  │   Manager    │  │   Manager    │  │    Manager     │   │
│  │              │  │              │  │                │   │
│  │ - Register   │  │ - Create     │  │ - Send         │   │
│  │ - Login      │  │ - Get Chats  │  │ - Get History  │   │
│  │ - Status     │  │ - Groups     │  │ - Mark Read    │   │
│  └──────────────┘  └──────────────┘  └────────────────┘   │
└─────────────────────────────────────────────────────────────┘
                            │
                            │ Mongoose ODM
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                      Data Layer                              │
│  ┌────────────────────────────────────────────────────┐    │
│  │              MongoDB Atlas (Cloud)                  │    │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────────┐     │    │
│  │  │  Users   │  │  Chats   │  │   Messages   │     │    │
│  │  │Collection│  │Collection│  │  Collection  │     │    │
│  │  └──────────┘  └──────────┘  └──────────────┘     │    │
│  └────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
```

## 3. Component Architecture

### 3.1 Frontend Components

#### 3.1.1 Authentication Module
- **Purpose**: Handle user registration and login
- **Components**:
  - Login Form
  - Registration Form
  - Form Validation
  - Session Management
- **Technologies**: HTML5, CSS3, Vanilla JavaScript

#### 3.1.2 Chat Interface Module
- **Purpose**: Display and manage chat conversations
- **Components**:
  - Sidebar (Chat List)
  - Main Chat Area
  - Message Composer
  - User List Modal
  - Group Creation Modal
- **State Management**: Class-based client (QuickChatClient)

#### 3.1.3 WebSocket Client
- **Purpose**: Manage real-time communication
- **Responsibilities**:
  - Establish and maintain WebSocket connection
  - Send and receive messages
  - Handle reconnection logic
  - Process real-time events

### 3.2 Backend Components

#### 3.2.1 API Server (Express.js)
- **Purpose**: Handle HTTP requests
- **Endpoints**:
  - POST /api/auth/register - User registration
  - POST /api/auth/login - User authentication
  - GET /api/users - Fetch user list
  - GET / - Serve static files

#### 3.2.2 WebSocket Server
- **Purpose**: Enable real-time bidirectional communication
- **Events Handled**:
  - auth - User authentication
  - get_users - Fetch users
  - get_chats - Fetch user chats
  - start_chat - Create/open private chat
  - create_group - Create group chat
  - send_message - Send message
  - typing - Typing indicator
  - mark_read - Mark messages as read

#### 3.2.3 Business Logic Layer

**UserManager**
- User registration and authentication
- Online/offline status management
- User data retrieval
- WebSocket connection mapping

**ChatManager**
- Private chat creation and retrieval
- Group chat management
- Chat list with unread counts
- Last message tracking

**MessageManager**
- Message creation and storage
- Message history retrieval
- Message status updates (sent/delivered/read)
- Unread count calculation

### 3.3 Database Layer

#### 3.3.1 Data Models

**User Schema**
```javascript
{
  username: String (unique, required),
  email: String (unique, required),
  password: String (hashed, required),
  profilePicture: String,
  status: String,
  isOnline: Boolean,
  lastSeen: Date,
  timestamps: true
}
```

**Chat Schema**
```javascript
{
  participants: [ObjectId] (User references),
  chatType: String (private/group),
  groupName: String,
  groupAdmin: ObjectId (User reference),
  lastMessage: ObjectId (Message reference),
  lastActivity: Date,
  createdAt: Date
}
```

**Message Schema**
```javascript
{
  chatId: ObjectId (Chat reference),
  sender: ObjectId (User reference),
  content: String,
  messageType: String (text/image/file),
  status: String (sent/delivered/read),
  readBy: [{user: ObjectId, readAt: Date}],
  createdAt: Date,
  isDeleted: Boolean
}
```

## 4. Data Flow

### 4.1 User Registration Flow
```
1. User fills registration form
2. Frontend validates input
3. POST request to /api/auth/register
4. UserManager validates and hashes password
5. User document created in MongoDB
6. Success response with user data
7. User redirected to login
```

### 4.2 User Login Flow
```
1. User submits credentials
2. POST request to /api/auth/login
3. UserManager verifies email and password
4. User status set to online
5. User data stored in localStorage
6. WebSocket connection established
7. Chat interface displayed
```

### 4.3 Send Message Flow
```
1. User types and sends message
2. WebSocket 'send_message' event triggered
3. MessageManager creates message in database
4. ChatManager updates lastMessage reference
5. Server broadcasts to all chat participants
6. Recipients' UI updates with new message
7. Message status updated (delivered/read)
```

### 4.4 Real-time Status Update Flow
```
1. User connects/disconnects WebSocket
2. UserManager updates online status
3. broadcastUserStatus() called
4. All connected clients receive status update
5. Chat list and headers update in real-time
```

## 5. Communication Protocols

### 5.1 HTTP/HTTPS
- Used for: REST API calls (registration, login, user list)
- Method: Request-Response
- Format: JSON

### 5.2 WebSocket
- Used for: Real-time messaging and events
- Method: Bidirectional persistent connection
- Format: JSON messages with type and payload

### 5.3 WebSocket Message Types

**Client to Server:**
- auth, get_users, get_chats, start_chat, create_group, open_group_chat, send_message, typing, mark_read

**Server to Client:**
- auth_success, auth_error, users_list, chats_list, chat_started, group_created, added_to_group, new_message, user_typing, user_status, messages_read

## 6. Security Architecture

### 6.1 Authentication
- Password hashing using bcrypt (12 salt rounds)
- Session persistence in browser localStorage
- WebSocket authentication on connection

### 6.2 Data Protection
- Environment variables for sensitive configuration
- .env file excluded from version control
- MongoDB connection string encryption

### 6.3 Input Validation
- Client-side form validation
- Server-side data sanitization
- HTML escaping for XSS prevention

## 7. Scalability Considerations

### 7.1 Horizontal Scaling
- Stateless REST API design
- WebSocket connection management
- Database sharding capability (MongoDB Atlas)

### 7.2 Performance Optimization
- Database indexing on frequently queried fields
- Efficient WebSocket connection pooling
- Lazy loading of chat history

### 7.3 Caching Strategy
- Client-side caching of user data
- In-memory storage of active WebSocket connections
- Message pagination to reduce payload

## 8. Deployment Architecture

### 8.1 Hosting Platform: Render
- Automatic deployment from GitHub
- Environment variable configuration
- Dynamic port binding
- Auto-scaling capability

### 8.2 Database: MongoDB Atlas
- Cloud-hosted database
- Automatic backups
- Replica sets for high availability
- Global distribution

### 8.3 CI/CD Pipeline
```
GitHub Repository → Render Auto-Deploy → Build → Deploy → Live
```

## 9. Monitoring and Logging

### 9.1 Application Logs
- Server startup/shutdown events
- WebSocket connection/disconnection
- Database connection status
- Error logging with stack traces

### 9.2 Error Handling
- Try-catch blocks for async operations
- Graceful error responses to clients
- WebSocket reconnection on failure
- Database connection retry logic

## 10. System Constraints

### 10.1 Technical Constraints
- Single server instance (Render free tier)
- WebSocket connections limited by server resources
- No CDN for static assets
- No load balancer

### 10.2 Performance Limits
- Maximum 100 concurrent WebSocket connections
- Message size limit: 5000 characters
- Chat history limit: 50 messages per fetch

## 11. Integration Points

### 11.1 External Services
- MongoDB Atlas - Database service
- Render - Hosting platform
- Font Awesome - Icon library

### 11.2 Internal Integrations
- Express.js ↔ WebSocket Server
- Business Logic Layer ↔ Data Layer
- Frontend ↔ Backend API

## 12. Future Architecture Enhancements

### 12.1 Planned Improvements
- Redis for session management
- Message queue (RabbitMQ/Kafka) for reliable delivery
- CDN for static asset delivery
- Microservices architecture for scalability
- Load balancer for multi-instance deployment
- Elasticsearch for message search
- S3 for file storage
