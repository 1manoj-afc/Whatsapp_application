const User = require('../models/User');

class UserManager {
    constructor() {
        this.onlineUsers = new Map();
    }

    async registerUser(username, email, password) {
        try {
            const existingUser = await User.findOne({
                $or: [{ username }, { email }]
            });

            if (existingUser) {
                if (existingUser.username === username) {
                    throw new Error('Username already taken');
                }
                throw new Error('Email already registered');
            }

            const user = new User({ username, email, password });
            await user.save();

            return {
                success: true,
                user: {
                    _id: user._id,
                    username: user.username,
                    email: user.email,
                    status: user.status,
                    profilePicture: user.profilePicture
                }
            };
        } catch (error) {
            throw error;
        }
    }

    async loginUser(email, password) {
        try {
            const user = await User.findOne({ email });
            
            if (!user) {
                throw new Error('Invalid email or password');
            }

            const isMatch = await user.comparePassword(password);
            
            if (!isMatch) {
                throw new Error('Invalid email or password');
            }

            user.isOnline = true;
            await user.save();

            return {
                success: true,
                user: {
                    _id: user._id,
                    username: user.username,
                    email: user.email,
                    status: user.status,
                    profilePicture: user.profilePicture,
                    isOnline: user.isOnline
                }
            };
        } catch (error) {
            throw error;
        }
    }

    async setUserOnline(userId, ws) {
        await User.findByIdAndUpdate(userId, { isOnline: true });
        this.onlineUsers.set(userId.toString(), ws);
    }

    async setUserOffline(userId) {
        await User.findByIdAndUpdate(userId, { 
            isOnline: false, 
            lastSeen: new Date() 
        });
        this.onlineUsers.delete(userId.toString());
    }

    getConnection(userId) {
        return this.onlineUsers.get(userId.toString());
    }

    isUserOnline(userId) {
        return this.onlineUsers.has(userId.toString());
    }

    async getAllUsers(excludeUserId) {
        return await User.find({ _id: { $ne: excludeUserId } })
            .select('username email status profilePicture isOnline lastSeen')
            .sort({ isOnline: -1, username: 1 });
    }

    async getUserById(userId) {
        return await User.findById(userId)
            .select('username email status profilePicture isOnline lastSeen');
    }
}

module.exports = UserManager;
