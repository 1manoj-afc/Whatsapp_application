const Message = require('../models/Message');

class MessageManager {
    constructor(chatManager) {
        this.chatManager = chatManager;
    }

    async createMessage(chatId, senderId, content, messageType = 'text') {
        try {
            const message = new Message({
                chatId,
                sender: senderId,
                content,
                messageType,
                status: 'sent'
            });

            await message.save();

            if (this.chatManager) {
                await this.chatManager.updateLastMessage(chatId, message._id);
            }

            await message.populate('sender', 'username profilePicture');

            return { success: true, message };
        } catch (error) {
            console.error('Error creating message:', error);
            return { success: false, error: error.message };
        }
    }

    async getChatMessages(chatId, limit = 50) {
        try {
            const messages = await Message.find({ chatId, isDeleted: false })
                .populate('sender', 'username profilePicture')
                .sort({ createdAt: 1 })
                .limit(limit);

            return messages;
        } catch (error) {
            console.error('Error getting chat messages:', error);
            return [];
        }
    }

    async markAsDelivered(messageId) {
        try {
            return await Message.findByIdAndUpdate(
                messageId,
                { status: 'delivered' },
                { new: true }
            );
        } catch (error) {
            console.error('Error marking as delivered:', error);
            return null;
        }
    }

    async markMessagesAsRead(chatId, userId) {
        try {
            await Message.updateMany(
                { 
                    chatId, 
                    sender: { $ne: userId },
                    status: { $ne: 'read' }
                },
                { status: 'read' }
            );
            return { success: true };
        } catch (error) {
            console.error('Error marking messages as read:', error);
            return { success: false };
        }
    }

    async getUnreadCount(chatId, userId) {
        try {
            return await Message.countDocuments({
                chatId,
                sender: { $ne: userId },
                status: { $ne: 'read' }
            });
        } catch (error) {
            console.error('Error getting unread count:', error);
            return 0;
        }
    }
}

module.exports = MessageManager;
