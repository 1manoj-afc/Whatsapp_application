const Chat = require('../models/Chat');
const Message = require('../models/Message');

class ChatManager {
    async createOrGetChat(participants) {
        try {
            if (participants.length === 2) {
                const existingChat = await Chat.findOne({
                    chatType: 'private',
                    participants: { $all: participants, $size: 2 }
                }).populate('participants', 'username profilePicture isOnline lastSeen status');

                if (existingChat) {
                    return existingChat;
                }
            }

            const chat = new Chat({
                participants,
                chatType: participants.length > 2 ? 'group' : 'private'
            });
            await chat.save();
            await chat.populate('participants', 'username profilePicture isOnline lastSeen status');

            return chat;
        } catch (error) {
            console.error('Error creating/getting chat:', error);
            throw error;
        }
    }

    async createGroupChat(groupName, participants, creatorId) {
        try {
            if (!participants.includes(creatorId)) {
                participants.push(creatorId);
            }

            if (participants.length < 2) {
                throw new Error('Group must have at least 2 members');
            }

            const chat = new Chat({
                participants,
                chatType: 'group',
                groupName: groupName || 'New Group',
                groupAdmin: creatorId
            });
            await chat.save();
            await chat.populate('participants', 'username profilePicture isOnline lastSeen status');

            return chat;
        } catch (error) {
            console.error('Error creating group chat:', error);
            throw error;
        }
    }

    async addGroupMember(chatId, userId) {
        try {
            const chat = await Chat.findById(chatId);
            if (!chat || chat.chatType !== 'group') {
                throw new Error('Group not found');
            }

            if (!chat.participants.includes(userId)) {
                chat.participants.push(userId);
                await chat.save();
            }

            await chat.populate('participants', 'username profilePicture isOnline lastSeen status');
            return chat;
        } catch (error) {
            console.error('Error adding group member:', error);
            throw error;
        }
    }

    async removeGroupMember(chatId, userId, adminId) {
        try {
            const chat = await Chat.findById(chatId);
            if (!chat || chat.chatType !== 'group') {
                throw new Error('Group not found');
            }

            if (chat.groupAdmin?.toString() !== adminId.toString()) {
                throw new Error('Only admin can remove members');
            }

            chat.participants = chat.participants.filter(p => p.toString() !== userId.toString());
            await chat.save();
            await chat.populate('participants', 'username profilePicture isOnline lastSeen status');
            return chat;
        } catch (error) {
            console.error('Error removing group member:', error);
            throw error;
        }
    }

    async updateGroupName(chatId, groupName, userId) {
        try {
            const chat = await Chat.findById(chatId);
            if (!chat || chat.chatType !== 'group') {
                throw new Error('Group not found');
            }

            chat.groupName = groupName;
            await chat.save();
            await chat.populate('participants', 'username profilePicture isOnline lastSeen status');
            return chat;
        } catch (error) {
            console.error('Error updating group name:', error);
            throw error;
        }
    }

    async getUserChats(userId) {
        try {
            const chats = await Chat.find({ participants: userId })
                .populate('participants', 'username profilePicture isOnline lastSeen status')
                .populate({
                    path: 'lastMessage',
                    populate: {
                        path: 'sender',
                        select: 'username'
                    }
                })
                .sort({ lastActivity: -1 });

            const chatsWithUnread = await Promise.all(
                chats.map(async (chat) => {
                    const unreadCount = await Message.countDocuments({
                        chatId: chat._id,
                        sender: { $ne: userId },
                        status: { $ne: 'read' }
                    });
                    return {
                        ...chat.toObject(),
                        unreadCount
                    };
                })
            );

            return chatsWithUnread;
        } catch (error) {
            console.error('Error getting user chats:', error);
            return [];
        }
    }

    async getChatById(chatId) {
        try {
            const chat = await Chat.findById(chatId)
                .populate('participants', 'username profilePicture isOnline lastSeen status')
                .populate('lastMessage');
            return chat;
        } catch (error) {
            console.error('Error getting chat:', error);
            return null;
        }
    }

    async updateLastMessage(chatId, messageId) {
        try {
            const chat = await Chat.findByIdAndUpdate(
                chatId,
                { 
                    lastMessage: messageId,
                    lastActivity: new Date()
                },
                { new: true }
            );
            return chat;
        } catch (error) {
            console.error('Error updating last message:', error);
            return null;
        }
    }
}

module.exports = ChatManager;
