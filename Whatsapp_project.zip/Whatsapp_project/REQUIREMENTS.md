# QuickChat - Requirements Documentation

## 1. Project Overview

QuickChat is a real-time chat application that enables users to communicate through private and group conversations with instant message delivery using WebSocket technology.

## 2. Functional Requirements

### 2.1 User Management
- **FR1.1**: Users must be able to register with username, email, and password
- **FR1.2**: Users must be able to login with email and password
- **FR1.3**: User passwords must be securely hashed using bcrypt
- **FR1.4**: Users must be able to logout from the application
- **FR1.5**: System must track user online/offline status
- **FR1.6**: System must display user's last seen timestamp when offline

### 2.2 Authentication & Authorization
- **FR2.1**: User credentials must be validated during registration (minimum 3 characters for username, minimum 6 characters for password)
- **FR2.2**: System must prevent duplicate usernames and emails
- **FR2.3**: WebSocket connections must be authenticated before allowing message exchange
- **FR2.4**: Session must persist in browser localStorage

### 2.3 Private Chat
- **FR3.1**: Users must be able to view a list of all registered users
- **FR3.2**: Users must be able to start a private chat with any user
- **FR3.3**: System must create or retrieve existing chat between two users
- **FR3.4**: Users must be able to send text messages in real-time
- **FR3.5**: Users must be able to view chat history when opening a conversation
- **FR3.6**: System must display message status (sent, delivered, read)
- **FR3.7**: Messages must persist in the database

### 2.4 Group Chat
- **FR4.1**: Users must be able to create group chats with multiple participants
- **FR4.2**: Group creator must be designated as admin
- **FR4.3**: Groups must have a name provided by the creator
- **FR4.4**: All group participants must receive messages in real-time
- **FR4.5**: Group messages must display sender's name
- **FR4.6**: Group chat must show member count and online status

### 2.5 Real-Time Features
- **FR5.1**: Messages must be delivered instantly via WebSocket
- **FR5.2**: System must show typing indicator when a user is typing
- **FR5.3**: Typing indicator must auto-hide after 2 seconds of inactivity
- **FR5.4**: User online/offline status must update in real-time
- **FR5.5**: New messages must appear without page refresh
- **FR5.6**: Chat list must update when new messages arrive

### 2.6 User Interface
- **FR6.1**: Application must have a responsive dark-themed interface
- **FR6.2**: Chat list must display last message preview and timestamp
- **FR6.3**: Unread message count must be visible in chat list
- **FR6.4**: Active chat must be highlighted in the sidebar
- **FR6.5**: Messages must be timestamped with relative time formatting
- **FR6.6**: System must show "no chat selected" view initially
- **FR6.7**: Modal dialog must be provided for starting new chats

## 3. Non-Functional Requirements

### 3.1 Performance
- **NFR1.1**: Message delivery latency must be less than 500ms
- **NFR1.2**: Application must support at least 100 concurrent WebSocket connections
- **NFR1.3**: Database queries must be optimized with proper indexing
- **NFR1.4**: Chat list must load within 2 seconds

### 3.2 Security
- **NFR2.1**: All passwords must be hashed using bcrypt with salt rounds of 12
- **NFR2.2**: MongoDB connection string must be stored in environment variables
- **NFR2.3**: Sensitive data must not be exposed in client-side code
- **NFR2.4**: Input validation must be performed on both client and server side
- **NFR2.5**: XSS protection through HTML escaping in message display

### 3.3 Scalability
- **NFR3.1**: Application must be deployable on cloud platforms (Render)
- **NFR3.2**: Database must support horizontal scaling via MongoDB Atlas
- **NFR3.3**: WebSocket connections must be managed efficiently with proper cleanup
- **NFR3.4**: Application must handle WebSocket disconnections and reconnections

### 3.4 Reliability
- **NFR4.1**: System must automatically reconnect WebSocket after disconnection
- **NFR4.2**: Messages must be persisted before sending to ensure no data loss
- **NFR4.3**: Application must handle errors gracefully with user-friendly messages
- **NFR4.4**: Database connection failures must not crash the application

### 3.5 Usability
- **NFR5.1**: User interface must be intuitive and require no training
- **NFR5.2**: Application must be responsive on desktop and mobile devices
- **NFR5.3**: Visual feedback must be provided for all user actions
- **NFR5.4**: Error messages must be clear and actionable

### 3.6 Maintainability
- **NFR6.1**: Code must follow modular architecture with separation of concerns
- **NFR6.2**: Backend logic must be organized into manager classes
- **NFR6.3**: Frontend code must use class-based structure
- **NFR6.4**: Environment-specific configurations must be externalized

## 4. Technical Constraints

### 4.1 Technology Stack
- **TC1.1**: Backend must use Node.js and Express.js
- **TC1.2**: Real-time communication must use native WebSocket (ws library)
- **TC1.3**: Database must be MongoDB Atlas
- **TC1.4**: Frontend must use vanilla JavaScript (no frameworks)
- **TC1.5**: CSS must use custom styling without frameworks

### 4.2 Deployment
- **TC2.1**: Application must be deployable on Render platform
- **TC2.2**: Environment variables must be configurable via .env file
- **TC2.3**: Application must run on dynamic port assigned by hosting platform

## 5. System Limitations

### 5.1 Current Limitations
- **SL1.1**: No file/image sharing capability
- **SL1.2**: No message editing or deletion
- **SL1.3**: No user profile picture upload
- **SL1.4**: No group admin features (add/remove members)
- **SL1.5**: No message search functionality
- **SL1.6**: No push notifications
- **SL1.7**: No end-to-end encryption
- **SL1.8**: No voice/video calling

## 6. Future Enhancements

### 6.1 Planned Features
- **FE1.1**: File and image sharing
- **FE1.2**: Message editing and deletion
- **FE1.3**: User profile customization
- **FE1.4**: Advanced group management (add/remove members, admin rights)
- **FE1.5**: Message search and filtering
- **FE1.6**: Push notifications for new messages
- **FE1.7**: Read receipts for individual users
- **FE1.8**: Message reactions (emojis)
- **FE1.9**: Voice and video calling
- **FE1.10**: End-to-end encryption

## 7. User Stories

### Epic 1: User Registration and Authentication
- As a new user, I want to register with my email and password so that I can create an account
- As a registered user, I want to login with my credentials so that I can access my chats
- As a user, I want to stay logged in so that I don't have to login every time

### Epic 2: Private Messaging
- As a user, I want to see a list of all users so that I can start a conversation
- As a user, I want to send messages to another user so that I can communicate privately
- As a user, I want to see when my message is delivered and read
- As a user, I want to see when the other person is typing

### Epic 3: Group Chat
- As a user, I want to create a group chat so that I can talk to multiple people at once
- As a user, I want to see who sent each message in a group chat
- As a group member, I want to see how many members are online

### Epic 4: Real-time Communication
- As a user, I want to receive messages instantly without refreshing
- As a user, I want to see when other users come online or go offline
- As a user, I want the app to reconnect automatically if my connection drops

## 8. Acceptance Criteria

### AC1: User Registration
- Given valid credentials, when user submits registration form, then account is created and user is redirected to login
- Given duplicate email/username, when user attempts to register, then error message is displayed

### AC2: User Login
- Given valid credentials, when user submits login form, then user is authenticated and redirected to chat interface
- Given invalid credentials, when user attempts to login, then error message is displayed

### AC3: Send Message
- Given an open chat, when user types and sends a message, then message appears immediately in chat window
- Given a sent message, when recipient is online, then message status changes to delivered
- Given a delivered message, when recipient opens the chat, then message status changes to read

### AC4: Group Chat Creation
- Given selected participants and group name, when user creates group, then group is created with all members
- Given a new group, when message is sent, then all members receive the message in real-time

### AC5: Real-time Updates
- Given two users in a chat, when one user types, then typing indicator appears for the other user
- Given a user comes online, when other users have chat window open, then online status updates immediately
