class QuickChatClient {
    constructor() {
        this.ws = null;
        this.currentUser = null;
        this.currentChat = null;
        this.chats = [];
        this.users = [];
        this.selectedGroupMembers = [];
        this.typingTimeout = null;

        this.init();
    }

    init() {
        document.getElementById('show-register').addEventListener('click', (e) => {
            e.preventDefault();
            document.getElementById('login-form').classList.remove('active');
            document.getElementById('register-form').classList.add('active');
        });

        document.getElementById('show-login').addEventListener('click', (e) => {
            e.preventDefault();
            document.getElementById('register-form').classList.remove('active');
            document.getElementById('login-form').classList.add('active');
        });

        document.getElementById('login-form').addEventListener('submit', (e) => this.handleLogin(e));
        document.getElementById('register-form').addEventListener('submit', (e) => this.handleRegister(e));

        document.getElementById('send-btn').addEventListener('click', () => this.sendMessage());
        document.getElementById('message-input').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.sendMessage();
        });

        document.getElementById('message-input').addEventListener('input', () => this.handleTyping());

        document.getElementById('new-chat-btn').addEventListener('click', () => this.openNewChatModal());
        document.getElementById('close-modal').addEventListener('click', () => this.closeNewChatModal());

        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', () => this.switchTab(btn.dataset.tab));
        });

        document.getElementById('create-group-btn').addEventListener('click', () => this.createGroup());

        document.getElementById('group-name').addEventListener('input', () => this.updateCreateGroupButton());

        document.getElementById('logout-btn').addEventListener('click', () => this.logout());

        const storedUser = localStorage.getItem('quickchat_user');
        if (storedUser) {
            this.currentUser = JSON.parse(storedUser);
            this.showChatContainer();
            this.connectWebSocket();
        }
    }

    switchTab(tab) {
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tab === tab);
        });

        document.getElementById('private-tab').classList.toggle('active', tab === 'private');
        document.getElementById('group-tab').classList.toggle('active', tab === 'group');

        if (tab === 'group') {
            this.selectedGroupMembers = [];
            this.renderSelectedMembers();
            this.renderGroupUsersList();
            this.updateCreateGroupButton();
        }
    }

    async handleLogin(e) {
        e.preventDefault();
        const email = document.getElementById('login-email').value;
        const password = document.getElementById('login-password').value;
        const errorDiv = document.getElementById('login-error');

        try {
            const response = await fetch('/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error);
            }

            this.currentUser = data.user;
            localStorage.setItem('quickchat_user', JSON.stringify(data.user));
            errorDiv.textContent = '';
            this.showChatContainer();
            this.connectWebSocket();
        } catch (error) {
            errorDiv.textContent = error.message;
        }
    }

    async handleRegister(e) {
        e.preventDefault();
        const username = document.getElementById('register-username').value;
        const email = document.getElementById('register-email').value;
        const password = document.getElementById('register-password').value;
        const confirm = document.getElementById('register-confirm').value;
        const errorDiv = document.getElementById('register-error');
        const successDiv = document.getElementById('register-success');

        errorDiv.textContent = '';
        successDiv.textContent = '';

        if (password !== confirm) {
            errorDiv.textContent = 'Passwords do not match';
            return;
        }

        try {
            const response = await fetch('/api/auth/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, email, password })
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error);
            }

            successDiv.textContent = 'Registration successful! Please login.';
            document.getElementById('register-form').reset();
            
            setTimeout(() => {
                document.getElementById('register-form').classList.remove('active');
                document.getElementById('login-form').classList.add('active');
                successDiv.textContent = '';
            }, 2000);
        } catch (error) {
            errorDiv.textContent = error.message;
        }
    }

    showChatContainer() {
        document.getElementById('auth-container').classList.add('hidden');
        document.getElementById('chat-container').classList.remove('hidden');
        document.getElementById('current-username').textContent = this.currentUser.username;
    }

    connectWebSocket() {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        this.ws = new WebSocket(`${protocol}//${window.location.host}`);

        this.ws.onopen = () => {
            console.log('WebSocket connected');
            this.ws.send(JSON.stringify({
                type: 'auth',
                user: this.currentUser
            }));
        };

        this.ws.onmessage = (event) => {
            const data = JSON.parse(event.data);
            this.handleWebSocketMessage(data);
        };

        this.ws.onclose = () => {
            console.log('WebSocket disconnected');
            setTimeout(() => {
                if (this.currentUser) {
                    this.connectWebSocket();
                }
            }, 3000);
        };

        this.ws.onerror = (error) => {
            console.error('WebSocket error:', error);
        };
    }

    handleWebSocketMessage(data) {
        console.log('Received:', data.type);

        switch (data.type) {
            case 'auth_success':
                this.loadChats();
                break;

            case 'auth_error':
                // Clear invalid session and redirect to login
                localStorage.removeItem('whatsapp_user');
                this.currentUser = null;
                alert(data.error);
                document.getElementById('chat-container').classList.add('hidden');
                document.getElementById('auth-container').classList.remove('hidden');
                break;

            case 'chats_list':
                this.chats = data.chats;
                this.renderChatList();
                break;

            case 'users_list':
                this.users = data.users;
                this.renderUsersList();
                break;

            case 'chat_started':
                this.currentChat = data.chat;
                this.showChat(data.chat, data.messages);
                this.closeNewChatModal();
                this.loadChats();
                break;

            case 'group_created':
                this.currentChat = data.chat;
                this.showChat(data.chat, data.messages);
                this.closeNewChatModal();
                this.loadChats();
                break;

            case 'added_to_group':
                // Refresh chats when added to a new group
                this.loadChats();
                break;

            case 'new_message':
                this.handleNewMessage(data);
                break;

            case 'user_typing':
                this.showTypingIndicator(data);
                break;

            case 'user_status':
                this.updateUserStatus(data.userId, data.isOnline);
                break;

            case 'messages_read':
                this.updateMessageStatus(data.chatId);
                break;

            case 'error':
                console.error('Server error:', data.message);
                break;
        }
    }

    loadChats() {
        this.ws.send(JSON.stringify({ type: 'get_chats' }));
    }

    renderChatList() {
        const chatList = document.getElementById('chat-list');
        
        if (this.chats.length === 0) {
            chatList.innerHTML = `
                <div class="empty-chats">
                    <i class="fas fa-comments"></i>
                    <p>No chats yet</p>
                    <p>Click the + icon to start a conversation</p>
                </div>
            `;
            return;
        }

        chatList.innerHTML = this.chats.map(chat => {
            const isGroup = chat.chatType === 'group';
            const otherUser = !isGroup ? chat.participants.find(p => p._id !== this.currentUser._id) : null;
            const lastMsg = chat.lastMessage;
            const time = lastMsg ? this.formatTime(lastMsg.createdAt) : '';
            let preview = lastMsg ? lastMsg.content : 'No messages yet';
            
            // For group chats, show sender name in preview
            if (isGroup && lastMsg && lastMsg.sender) {
                const senderName = lastMsg.sender._id === this.currentUser._id ? 'You' : lastMsg.sender.username;
                preview = `${senderName}: ${lastMsg.content}`;
            }

            const displayName = isGroup ? chat.groupName : (otherUser?.username || 'Unknown User');
            const hasOnlineUser = isGroup 
                ? chat.participants.some(p => p._id !== this.currentUser._id && p.isOnline)
                : otherUser?.isOnline;

            return `
                <div class="chat-item ${isGroup ? 'group-chat' : ''} ${this.currentChat?._id === chat._id ? 'active' : ''}" 
                     data-chat-id="${chat._id}" 
                     data-chat-type="${chat.chatType}"
                     ${!isGroup ? `data-recipient-id="${otherUser?._id}"` : ''}>
                    <div class="avatar">
                        ${isGroup 
                            ? '<i class="fas fa-users group-icon"></i>' 
                            : '<i class="fas fa-user"></i>'}
                        ${hasOnlineUser && !isGroup ? '<span class="online-indicator"></span>' : ''}
                    </div>
                    <div class="chat-item-info">
                        <div class="chat-item-header">
                            <span class="chat-item-name">${this.escapeHtml(displayName)}</span>
                            <span class="chat-item-time">${time}</span>
                        </div>
                        <div class="chat-item-preview">
                            <span class="chat-item-message">${this.escapeHtml(preview.substring(0, 40))}</span>
                            ${chat.unreadCount > 0 ? `<span class="unread-badge">${chat.unreadCount}</span>` : ''}
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        chatList.querySelectorAll('.chat-item').forEach(item => {
            item.addEventListener('click', () => {
                const chatType = item.dataset.chatType;
                if (chatType === 'group') {
                    this.openGroupChat(item.dataset.chatId);
                } else {
                    const recipientId = item.dataset.recipientId;
                    this.startChat(recipientId);
                }
            });
        });
    }

    openGroupChat(chatId) {
        this.ws.send(JSON.stringify({
            type: 'open_group_chat',
            chatId
        }));
    }

    openNewChatModal() {
        document.getElementById('new-chat-modal').classList.remove('hidden');
        this.switchTab('private');
        this.selectedGroupMembers = [];
        document.getElementById('group-name').value = '';
        this.ws.send(JSON.stringify({ type: 'get_users' }));
    }

    closeNewChatModal() {
        document.getElementById('new-chat-modal').classList.add('hidden');
        this.selectedGroupMembers = [];
    }

    renderUsersList() {
        const usersList = document.getElementById('users-list');
        
        if (this.users.length === 0) {
            usersList.innerHTML = '<p style="text-align: center; color: var(--text-secondary);">No users found</p>';
            return;
        }

        usersList.innerHTML = this.users.map(user => `
            <div class="user-item" data-user-id="${user._id}">
                <div class="avatar">
                    <i class="fas fa-user"></i>
                    ${user.isOnline ? '<span class="online-indicator"></span>' : ''}
                </div>
                <div class="user-item-info">
                    <h4>${this.escapeHtml(user.username)}</h4>
                    <p>${user.isOnline ? 'Online' : 'Offline'}</p>
                </div>
            </div>
        `).join('');

        usersList.querySelectorAll('.user-item').forEach(item => {
            item.addEventListener('click', () => {
                const userId = item.dataset.userId;
                this.startChat(userId);
            });
        });

        this.renderGroupUsersList();
    }

    renderGroupUsersList() {
        const groupUsersList = document.getElementById('group-users-list');
        
        if (this.users.length === 0) {
            groupUsersList.innerHTML = '<p style="text-align: center; color: var(--text-secondary);">No users found</p>';
            return;
        }

        groupUsersList.innerHTML = this.users.map(user => {
            const isSelected = this.selectedGroupMembers.some(m => m._id === user._id);
            return `
                <div class="user-item ${isSelected ? 'selected' : ''}" data-user-id="${user._id}">
                    <div class="avatar">
                        <i class="fas fa-user"></i>
                        ${user.isOnline ? '<span class="online-indicator"></span>' : ''}
                    </div>
                    <div class="user-item-info">
                        <h4>${this.escapeHtml(user.username)}</h4>
                        <p>${user.isOnline ? 'Online' : 'Offline'}</p>
                    </div>
                    <div class="checkbox">
                        ${isSelected ? '<i class="fas fa-check"></i>' : ''}
                    </div>
                </div>
            `;
        }).join('');

        groupUsersList.querySelectorAll('.user-item').forEach(item => {
            item.addEventListener('click', () => {
                const userId = item.dataset.userId;
                this.toggleGroupMember(userId);
            });
        });
    }

    toggleGroupMember(userId) {
        const user = this.users.find(u => u._id === userId);
        if (!user) return;

        const existingIndex = this.selectedGroupMembers.findIndex(m => m._id === userId);
        
        if (existingIndex > -1) {
            this.selectedGroupMembers.splice(existingIndex, 1);
        } else {
            this.selectedGroupMembers.push(user);
        }

        this.renderSelectedMembers();
        this.renderGroupUsersList();
        this.updateCreateGroupButton();
    }

    renderSelectedMembers() {
        const container = document.getElementById('selected-members');
        
        if (this.selectedGroupMembers.length === 0) {
            container.innerHTML = '<span style="color: var(--text-secondary); font-size: 13px;">No members selected</span>';
            return;
        }

        container.innerHTML = this.selectedGroupMembers.map(member => `
            <div class="selected-member" data-user-id="${member._id}">
                <span>${this.escapeHtml(member.username)}</span>
                <button class="remove-member" data-user-id="${member._id}">&times;</button>
            </div>
        `).join('');

        container.querySelectorAll('.remove-member').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const userId = btn.dataset.userId;
                this.toggleGroupMember(userId);
            });
        });
    }

    updateCreateGroupButton() {
        const btn = document.getElementById('create-group-btn');
        const groupName = document.getElementById('group-name').value.trim();
        
        btn.disabled = !groupName || this.selectedGroupMembers.length < 1;
    }

    createGroup() {
        const groupName = document.getElementById('group-name').value.trim();
        
        if (!groupName || this.selectedGroupMembers.length < 1) {
            return;
        }

        const participantIds = this.selectedGroupMembers.map(m => m._id);

        this.ws.send(JSON.stringify({
            type: 'create_group',
            groupName,
            participantIds
        }));
    }

    startChat(recipientId) {
        this.ws.send(JSON.stringify({
            type: 'start_chat',
            recipientId
        }));
    }

    showChat(chat, messages) {
        this.currentChat = chat;
        
        document.getElementById('no-chat-selected').classList.add('hidden');
        document.getElementById('active-chat').classList.remove('hidden');

        const isGroup = chat.chatType === 'group';
        
        if (isGroup) {
            document.getElementById('chat-user-name').textContent = chat.groupName;
            const memberCount = chat.participants.length;
            const onlineCount = chat.participants.filter(p => p.isOnline).length;
            document.getElementById('chat-user-status').textContent = 
                `${memberCount} members, ${onlineCount} online`;
        } else {
            const otherUser = chat.participants.find(p => p._id !== this.currentUser._id);
            document.getElementById('chat-user-name').textContent = otherUser.username;
            document.getElementById('chat-user-status').textContent = 
                otherUser.isOnline ? 'online' : `last seen ${this.formatTime(otherUser.lastSeen)}`;
        }

        this.renderMessages(messages, isGroup);

        this.ws.send(JSON.stringify({
            type: 'mark_read',
            chatId: chat._id
        }));

        document.getElementById('message-input').focus();

        document.querySelectorAll('.chat-item').forEach(item => {
            item.classList.toggle('active', item.dataset.chatId === chat._id);
        });
    }

    renderMessages(messages, isGroup = false) {
        const container = document.getElementById('messages-container');
        
        container.innerHTML = messages.map(msg => {
            const isSent = msg.sender._id === this.currentUser._id;
            const statusIcon = this.getStatusIcon(msg.status);
            const senderName = isGroup && !isSent ? msg.sender.username : null;

            return `
                <div class="message ${isSent ? 'sent' : 'received'}">
                    ${senderName ? `<div class="sender-name">${this.escapeHtml(senderName)}</div>` : ''}
                    <div class="message-content">${this.escapeHtml(msg.content)}</div>
                    <div class="message-meta">
                        <span class="message-time">${this.formatTime(msg.createdAt)}</span>
                        ${isSent ? `<span class="message-status ${msg.status}">${statusIcon}</span>` : ''}
                    </div>
                </div>
            `;
        }).join('');

        container.scrollTop = container.scrollHeight;
    }

    getStatusIcon(status) {
        switch (status) {
            case 'sent': return '<i class="fas fa-check"></i>';
            case 'delivered': return '<i class="fas fa-check-double"></i>';
            case 'read': return '<i class="fas fa-check-double"></i>';
            default: return '<i class="fas fa-clock"></i>';
        }
    }

    sendMessage() {
        const input = document.getElementById('message-input');
        const content = input.value.trim();

        if (!content || !this.currentChat) return;

        this.ws.send(JSON.stringify({
            type: 'send_message',
            chatId: this.currentChat._id,
            content
        }));

        input.value = '';
    }

    handleNewMessage(data) {
        if (this.currentChat && data.chatId === this.currentChat._id) {
            const container = document.getElementById('messages-container');
            const isSent = data.message.sender._id === this.currentUser._id;
            const statusIcon = this.getStatusIcon(data.message.status);
            const isGroup = this.currentChat.chatType === 'group';
            const senderName = isGroup && !isSent ? data.message.sender.username : null;

            const messageHtml = `
                <div class="message ${isSent ? 'sent' : 'received'}">
                    ${senderName ? `<div class="sender-name">${this.escapeHtml(senderName)}</div>` : ''}
                    <div class="message-content">${this.escapeHtml(data.message.content)}</div>
                    <div class="message-meta">
                        <span class="message-time">${this.formatTime(data.message.createdAt)}</span>
                        ${isSent ? `<span class="message-status ${data.message.status}">${statusIcon}</span>` : ''}
                    </div>
                </div>
            `;

            container.insertAdjacentHTML('beforeend', messageHtml);
            container.scrollTop = container.scrollHeight;

            document.getElementById('typing-indicator').classList.add('hidden');

            if (!isSent) {
                this.ws.send(JSON.stringify({
                    type: 'mark_read',
                    chatId: this.currentChat._id
                }));
            }
        }

        this.loadChats();
    }

    handleTyping() {
        if (!this.currentChat) return;

        this.ws.send(JSON.stringify({
            type: 'typing',
            chatId: this.currentChat._id,
            isTyping: true
        }));

        if (this.typingTimeout) {
            clearTimeout(this.typingTimeout);
        }

        this.typingTimeout = setTimeout(() => {
            this.ws.send(JSON.stringify({
                type: 'typing',
                chatId: this.currentChat._id,
                isTyping: false
            }));
        }, 2000);
    }

    showTypingIndicator(data) {
        if (this.currentChat?._id !== data.chatId) return;
        if (data.user._id === this.currentUser._id) return;

        const indicator = document.getElementById('typing-indicator');
        if (data.isTyping) {
            indicator.innerHTML = `<span>${this.escapeHtml(data.user.username)}</span> is typing...`;
            indicator.classList.remove('hidden');
        } else {
            indicator.classList.add('hidden');
        }
    }

    updateUserStatus(userId, isOnline) {
        const user = this.users.find(u => u._id === userId);
        if (user) {
            user.isOnline = isOnline;
        }

        this.chats.forEach(chat => {
            chat.participants.forEach(p => {
                if (p._id === userId) {
                    p.isOnline = isOnline;
                }
            });
        });

        this.renderChatList();

        if (this.currentChat) {
            const isGroup = this.currentChat.chatType === 'group';
            
            if (isGroup) {
                const memberCount = this.currentChat.participants.length;
                const onlineCount = this.currentChat.participants.filter(p => p.isOnline).length;
                document.getElementById('chat-user-status').textContent = 
                    `${memberCount} members, ${onlineCount} online`;
            } else {
                const otherUser = this.currentChat.participants.find(p => p._id !== this.currentUser._id);
                if (otherUser._id === userId) {
                    document.getElementById('chat-user-status').textContent = 
                        isOnline ? 'online' : 'offline';
                }
            }
        }
    }

    updateMessageStatus(chatId) {
        if (this.currentChat?._id === chatId) {
            document.querySelectorAll('.message.sent .message-status').forEach(el => {
                el.classList.add('read');
                el.innerHTML = '<i class="fas fa-check-double"></i>';
            });
        }
    }

    logout() {
        localStorage.removeItem('quickchat_user');
        if (this.ws) {
            this.ws.close();
        }
        this.currentUser = null;
        this.currentChat = null;
        this.chats = [];
        
        document.getElementById('chat-container').classList.add('hidden');
        document.getElementById('auth-container').classList.remove('hidden');
        document.getElementById('login-form').reset();
    }

    formatTime(dateStr) {
        if (!dateStr) return '';
        const date = new Date(dateStr);
        const now = new Date();
        const diff = now - date;
        const oneDay = 24 * 60 * 60 * 1000;

        if (diff < oneDay && date.getDate() === now.getDate()) {
            return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        } else if (diff < 7 * oneDay) {
            return date.toLocaleDateString([], { weekday: 'short' });
        } else {
            return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
        }
    }

    escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

const app = new QuickChatClient();
