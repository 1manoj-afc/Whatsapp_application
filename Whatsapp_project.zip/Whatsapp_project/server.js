require('dotenv').config();
const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');

const { connectDB } = require('./config/database');
const { UserManager, ChatManager, MessageManager } = require('./classes');

const app = express();
const server = http.createServer(app);

const wss = new WebSocket.Server({ server });

const userManager = new UserManager();
const chatManager = new ChatManager();
const messageManager = new MessageManager(chatManager);

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.post('/api/auth/register', async (req, res) => {
    try {
        const { username, email, password } = req.body;
        
        if (!username || !email || !password) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        if (password.length < 6) {
            return res.status(400).json({ error: 'Password must be at least 6 characters' });
        }

        const result = await userManager.registerUser(username, email, password);
        res.status(201).json(result);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

app.post('/api/auth/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        
        if (!email || !password) {
            return res.status(400).json({ error: 'Email and password are required' });
        }

        const result = await userManager.loginUser(email, password);
        res.json(result);
    } catch (error) {
        res.status(401).json({ error: error.message });
    }
});

app.get('/api/users', async (req, res) => {
    try {
        const { excludeUserId } = req.query;
        const users = await userManager.getAllUsers(excludeUserId);
        res.json(users);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

function broadcastUserStatus(userId, isOnline) {
    wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify({
                type: 'user_status',
                userId,
                isOnline
            }));
        }
    });
}

wss.on('connection', (ws) => {
    console.log('New WebSocket connection');
    
    let currentUser = null;

    ws.on('message', async (data) => {
        try {
            const message = JSON.parse(data);
            console.log('Received:', message.type);

            switch (message.type) {
                case 'auth': {
                    currentUser = message.user;
                    
                    if (!currentUser || !currentUser._id) {
                        ws.send(JSON.stringify({
                            type: 'auth_error',
                            error: 'Invalid user data. Please login again.'
                        }));
                        break;
                    }
                    
                    await userManager.setUserOnline(currentUser._id, ws);
                    
                    ws.send(JSON.stringify({
                        type: 'auth_success',
                        user: currentUser
                    }));

                    broadcastUserStatus(currentUser._id, true);
                    break;
                }

                case 'get_users': {
                    const users = await userManager.getAllUsers(currentUser._id);
                    ws.send(JSON.stringify({
                        type: 'users_list',
                        users
                    }));
                    break;
                }

                case 'get_chats': {
                    const chats = await chatManager.getUserChats(currentUser._id);
                    ws.send(JSON.stringify({
                        type: 'chats_list',
                        chats
                    }));
                    break;
                }

                case 'start_chat': {
                    const { recipientId } = message;
                    const chat = await chatManager.createOrGetChat([currentUser._id, recipientId]);
                    
                    const chatMessages = await messageManager.getChatMessages(chat._id);
                    
                    ws.send(JSON.stringify({
                        type: 'chat_started',
                        chat,
                        messages: chatMessages
                    }));
                    break;
                }

                case 'create_group': {
                    const { groupName, participantIds } = message;
                    
                    if (!groupName || !participantIds || participantIds.length < 1) {
                        ws.send(JSON.stringify({
                            type: 'error',
                            message: 'Group name and at least 1 other participant are required'
                        }));
                        break;
                    }

                    const groupChat = await chatManager.createGroupChat(groupName, participantIds, currentUser._id);
                    
                    const groupMessages = await messageManager.getChatMessages(groupChat._id);
                    
                    ws.send(JSON.stringify({
                        type: 'group_created',
                        chat: groupChat,
                        messages: groupMessages
                    }));

                    participantIds.forEach(participantId => {
                        if (participantId !== currentUser._id) {
                            const participantWs = userManager.getConnection(participantId);
                            if (participantWs && participantWs.readyState === WebSocket.OPEN) {
                                participantWs.send(JSON.stringify({
                                    type: 'added_to_group',
                                    chat: groupChat
                                }));
                            }
                        }
                    });
                    break;
                }

                case 'open_group_chat': {
                    const { chatId } = message;
                    const chat = await chatManager.getChatById(chatId);
                    
                    if (!chat) {
                        ws.send(JSON.stringify({
                            type: 'error',
                            message: 'Chat not found'
                        }));
                        break;
                    }

                    const messages = await messageManager.getChatMessages(chatId);
                    
                    ws.send(JSON.stringify({
                        type: 'chat_started',
                        chat,
                        messages
                    }));
                    break;
                }

                case 'get_messages': {
                    const msgs = await messageManager.getChatMessages(message.chatId);
                    ws.send(JSON.stringify({
                        type: 'messages_list',
                        chatId: message.chatId,
                        messages: msgs
                    }));
                    break;
                }

                case 'send_message': {
                    const { chatId, content } = message;
                    const result = await messageManager.createMessage(chatId, currentUser._id, content);

                    if (result.success) {
                        const chatInfo = await chatManager.getChatById(chatId);

                        chatInfo.participants.forEach(participant => {
                            const participantWs = userManager.getConnection(participant._id);
                            if (participantWs && participantWs.readyState === WebSocket.OPEN) {
                                participantWs.send(JSON.stringify({
                                    type: 'new_message',
                                    message: result.message,
                                    chatId
                                }));

                                if (participant._id.toString() !== currentUser._id.toString()) {
                                    messageManager.markAsDelivered(result.message._id);
                                }
                            }
                        });
                    }
                    break;
                }

                case 'typing': {
                    const { chatId, isTyping } = message;
                    const typingChat = await chatManager.getChatById(chatId);
                    
                    typingChat.participants.forEach(participant => {
                        if (participant._id.toString() !== currentUser._id.toString()) {
                            const participantWs = userManager.getConnection(participant._id);
                            if (participantWs && participantWs.readyState === WebSocket.OPEN) {
                                participantWs.send(JSON.stringify({
                                    type: 'user_typing',
                                    chatId,
                                    user: currentUser,
                                    isTyping
                                }));
                            }
                        }
                    });
                    break;
                }

                case 'mark_read': {
                    const { chatId } = message;
                    await messageManager.markMessagesAsRead(chatId, currentUser._id);
                    
                    const readChat = await chatManager.getChatById(chatId);
                    readChat.participants.forEach(participant => {
                        if (participant._id.toString() !== currentUser._id.toString()) {
                            const participantWs = userManager.getConnection(participant._id);
                            if (participantWs && participantWs.readyState === WebSocket.OPEN) {
                                participantWs.send(JSON.stringify({
                                    type: 'messages_read',
                                    chatId,
                                    readBy: currentUser._id
                                }));
                            }
                        }
                    });
                    break;
                }

                default:
                    console.log('Unknown message type:', message.type);
            }
        } catch (error) {
            console.error('WebSocket error:', error);
            ws.send(JSON.stringify({
                type: 'error',
                message: error.message
            }));
        }
    });

    ws.on('close', async () => {
        if (currentUser) {
            await userManager.setUserOffline(currentUser._id);
            broadcastUserStatus(currentUser._id, false);
            console.log(`User ${currentUser.username} disconnected`);
        }
    });

    ws.on('error', (error) => {
        console.error('WebSocket error:', error);
    });
});

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 3000;

const startServer = async () => {
    try {
        await connectDB();
        server.listen(PORT, () => {
            console.log(`\n🚀 QuickChat Server running on http://localhost:${PORT}`);
            console.log(`📱 Open multiple browser tabs to test real-time messaging\n`);
        });
    } catch (error) {
        console.error('Failed to start server:', error);
        process.exit(1);
    }
};

startServer();
