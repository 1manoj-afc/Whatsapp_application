# QuickChat

A minimal chat application with real-time messaging using Node.js, WebSocket, and MongoDB Atlas.

## Features

- 🔐 User authentication (username-based)
- 💬 Real-time messaging with WebSocket
- 👥 Private chat functionality
- 👥 Group chat support
- 📝 Typing indicators
- 🟢 Online/offline status
- 💾 Persistent message storage in MongoDB Atlas
- 📱 Responsive chat UI

## Tech Stack

- **Backend**: Node.js, Express.js
- **Real-time**: WebSocket (ws)
- **Database**: MongoDB Atlas
- **Frontend**: Vanilla JavaScript, HTML5, CSS3

## Project Structure

```
quickchat/
├── classes/
│   ├── UserManager.js      # User operations
│   ├── ChatManager.js      # Chat operations
│   ├── MessageManager.js   # Message operations
│   └── index.js
├── config/
│   └── database.js         # MongoDB connection
├── models/
│   ├── User.js             # User schema
│   ├── Chat.js             # Chat schema
│   ├── Message.js          # Message schema
│   └── index.js
├── public/
│   ├── css/
│   │   └── style.css       # Styles
│   ├── js/
│   │   └── app.js          # Frontend app
│   └── index.html          # Main HTML
├── .env                    # Environment variables
├── .env.example            # Example env file
├── package.json
├── server.js               # Main server
└── README.md
```

## Setup Instructions

### Option 1: Deploy to Render (Recommended)

1. **MongoDB Atlas Setup**
   - Go to [MongoDB Atlas](https://www.mongodb.com/atlas)
   - Create a free account or sign in
   - Create a new cluster (free tier available)
   - Create a database user with password
   - Add `0.0.0.0/0` to the IP whitelist (to allow connections from anywhere)
   - Get your connection string

2. **Deploy to Render**
   - Push your code to GitHub
   - Go to [Render Dashboard](https://dashboard.render.com/)
   - Click "New +" and select "Web Service"
   - Connect your GitHub repository
   - Configure the service:
     - **Name**: quickchat (or your preferred name)
     - **Environment**: Node
     - **Build Command**: `npm install`
     - **Start Command**: `npm start`
     - **Instance Type**: Free
   - Add Environment Variables:
     - `MONGODB_URI`: Your MongoDB Atlas connection string
     - `PORT`: Leave empty (Render sets this automatically)
   - Click "Create Web Service"
   - Wait for deployment to complete
   - Your app will be live at `https://your-app-name.onrender.com`

### Option 2: Local Development

### Option 2: Local Development

### 1. MongoDB Atlas Setup

1. Go to [MongoDB Atlas](https://www.mongodb.com/atlas)
2. Create a free account or sign in
3. Create a new cluster (free tier available)
4. Create a database user with password
5. Add your IP address to the whitelist (or allow all IPs: 0.0.0.0/0)
6. Get your connection string

### 2. Configure Environment

Create a `.env` file in the root directory with your MongoDB connection string:

```env
MONGODB_URI=mongodb+srv://your-username:your-password@cluster0.xxxxx.mongodb.net/quickchat?retryWrites=true&w=majority
PORT=3000
```

### 3. Install Dependencies

```bash
npm install
```

### 4. Start the Server

```bash
npm start
```

Or for development with auto-reload:

```bash
npm run dev
```

### 5. Test the Application

1. Open http://localhost:3000 in your browser
2. Register a new account with username, email, and password
3. Login with your credentials
4. Open another browser tab (or incognito window)
5. Register and login with a different account
6. Click the "New Chat" icon to start a conversation
7. Select the other user and start messaging!

## Deployment Notes

### Render Deployment
- Render automatically sets the `PORT` environment variable
- Make sure to set `MONGODB_URI` in Render's environment variables
- The free tier may experience cold starts (app sleeps after inactivity)
- WebSocket connections work out of the box on Render

### Environment Variables Required
- `MONGODB_URI`: Your MongoDB Atlas connection string (required)
- `PORT`: Server port (automatically set by Render, defaults to 3000 locally)

## Real-time Features Demo

### Messaging
- Messages are delivered instantly via WebSocket
- Messages are stored in MongoDB for persistence

### Typing Indicator
- Shows when other user is typing
- Automatically clears after 2 seconds of inactivity

### Online Status
- Green dot indicates online users
- Status updates in real-time when users connect/disconnect

## API Endpoints

### REST
- `GET /` - Serve the web application
- `GET /api/health` - Health check endpoint

### WebSocket Messages

**Client → Server:**
- `auth` - Authenticate user
- `get_users` - Get all users
- `start_chat` - Start a new chat
- `get_messages` - Get chat messages
- `send_message` - Send a message
- `typing` - Send typing indicator
- `mark_read` - Mark messages as read

**Server → Client:**
- `auth_success` - Authentication successful
- `users_list` - List of users
- `chat_started` - New chat created
- `new_chat` - Notify of new chat
- `messages` - Chat messages
- `new_message` - New message received
- `typing` - Typing indicator
- `user_status` - User online/offline status

## Screenshots

The application features a dark theme with:
- Left sidebar for chat list
- Right panel for active conversation
- Modal for starting new chats
- Real-time message updates

## License

MIT
