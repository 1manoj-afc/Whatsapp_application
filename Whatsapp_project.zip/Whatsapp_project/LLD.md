# QuickChat - Low-Level Design (LLD)

## 1. Module Design

### 1.1 Backend Modules

#### 1.1.1 UserManager Class

**File**: `classes/UserManager.js`

**Purpose**: Manages user-related operations including registration, authentication, and online status tracking.

**Class Structure**:
```javascript
class UserManager {
  constructor()
  registerUser(username, email, password)
  loginUser(email, password)
  setUserOnline(userId, ws)
  setUserOffline(userId)
  getConnection(userId)
  isUserOnline(userId)
  getAllUsers(excludeUserId)
  getUserById(userId)
}
```

**Properties**:
- `onlineUsers`: Map<String, WebSocket> - Stores userId to WebSocket connection mapping

**Methods**:

**registerUser(username, email, password)**
- **Input**: String username, String email, String password
- **Output**: Object {success: Boolean, user: Object} or throws Error
- **Logic**:
  1. Check if username or email already exists
  2. If exists, throw error with specific message
  3. Create new User document with provided data
  4. Password automatically hashed by pre-save hook
  5. Save to database
  6. Return sanitized user object (exclude password)

**loginUser(email, password)**
- **Input**: String email, String password
- **Output**: Object {success: Boolean, user: Object} or throws Error
- **Logic**:
  1. Find user by email
  2. If not found, throw "Invalid email or password"
  3. Compare password using bcrypt via user.comparePassword()
  4. If mismatch, throw "Invalid email or password"
  5. Update user.isOnline = true
  6. Save to database
  7. Return sanitized user object

**setUserOnline(userId, ws)**
- **Input**: ObjectId userId, WebSocket ws
- **Output**: Promise<void>
- **Logic**:
  1. Update user document: isOnline = true
  2. Store WebSocket connection in onlineUsers Map
  3. Key: userId.toString(), Value: ws

**setUserOffline(userId)**
- **Input**: ObjectId userId
- **Output**: Promise<void>
- **Logic**:
  1. Update user document: isOnline = false, lastSeen = current timestamp
  2. Remove userId from onlineUsers Map

---

#### 1.1.2 ChatManager Class

**File**: `classes/ChatManager.js`

**Purpose**: Handles all chat-related operations for private and group conversations.

**Class Structure**:
```javascript
class ChatManager {
  createOrGetChat(participants)
  createGroupChat(groupName, participants, creatorId)
  addGroupMember(chatId, userId)
  removeGroupMember(chatId, userId, adminId)
  updateGroupName(chatId, groupName)
  getUserChats(userId)
  getChatById(chatId)
  updateLastMessage(chatId, messageId)
}
```

**Methods**:

**createOrGetChat(participants)**
- **Input**: Array<ObjectId> participants
- **Output**: Promise<Chat>
- **Logic**:
  1. If participants.length === 2:
     - Query for existing private chat with exact participants
     - If found, return existing chat
  2. If not found or group chat:
     - Create new Chat document
     - Set chatType based on participant count
     - Populate participant details
     - Return chat

**createGroupChat(groupName, participants, creatorId)**
- **Input**: String groupName, Array<ObjectId> participants, ObjectId creatorId
- **Output**: Promise<Chat>
- **Logic**:
  1. Ensure creatorId is in participants array
  2. Validate minimum 2 participants
  3. Create Chat document:
     - chatType: 'group'
     - groupName: provided or 'New Group'
     - groupAdmin: creatorId
     - participants: array
  4. Populate participant details
  5. Return group chat

**getUserChats(userId)**
- **Input**: ObjectId userId
- **Output**: Promise<Array<Chat>>
- **Logic**:
  1. Find all chats where userId in participants
  2. Populate participants and lastMessage
  3. Sort by lastActivity descending
  4. For each chat:
     - Count unread messages for userId
     - Add unreadCount to chat object
  5. Return chats with unread counts

**updateLastMessage(chatId, messageId)**
- **Input**: ObjectId chatId, ObjectId messageId
- **Output**: Promise<Chat>
- **Logic**:
  1. Update chat document:
     - lastMessage: messageId
     - lastActivity: current timestamp
  2. Return updated chat

---

#### 1.1.3 MessageManager Class

**File**: `classes/MessageManager.js`

**Purpose**: Manages message creation, retrieval, and status updates.

**Class Structure**:
```javascript
class MessageManager {
  constructor(chatManager)
  createMessage(chatId, senderId, content, messageType)
  getChatMessages(chatId, limit)
  markAsDelivered(messageId)
  markMessagesAsRead(chatId, userId)
  getUnreadCount(chatId, userId)
}
```

**Properties**:
- `chatManager`: ChatManager - Reference for updating last message

**Methods**:

**createMessage(chatId, senderId, content, messageType)**
- **Input**: ObjectId chatId, ObjectId senderId, String content, String messageType
- **Output**: Object {success: Boolean, message: Message}
- **Logic**:
  1. Create Message document:
     - chatId, sender, content, messageType
     - status: 'sent'
  2. Save to database
  3. Call chatManager.updateLastMessage(chatId, messageId)
  4. Populate sender details
  5. Return {success: true, message}
  6. On error: return {success: false, error}

**getChatMessages(chatId, limit)**
- **Input**: ObjectId chatId, Number limit (default: 50)
- **Output**: Promise<Array<Message>>
- **Logic**:
  1. Find messages where:
     - chatId matches
     - isDeleted === false
  2. Populate sender (username, profilePicture)
  3. Sort by createdAt ascending
  4. Limit to specified count
  5. Return messages array

**markMessagesAsRead(chatId, userId)**
- **Input**: ObjectId chatId, ObjectId userId
- **Output**: Promise<Object>
- **Logic**:
  1. Update multiple messages where:
     - chatId matches
     - sender !== userId (not own messages)
     - status !== 'read'
  2. Set status = 'read'
  3. Return {success: true}

---

#### 1.1.4 Server Module

**File**: `server.js`

**Purpose**: Main application server handling HTTP and WebSocket connections.

**Key Functions**:

**broadcastUserStatus(userId, isOnline)**
- **Input**: ObjectId userId, Boolean isOnline
- **Output**: void
- **Logic**:
  1. Iterate through all WebSocket clients
  2. If client.readyState === OPEN:
     - Send JSON message:
       ```json
       {
         "type": "user_status",
         "userId": userId,
         "isOnline": isOnline
       }
       ```

**WebSocket Connection Handler**
- **Event**: 'connection'
- **Logic**:
  1. Initialize currentUser = null
  2. Set up message handler
  3. Set up close handler
  4. Set up error handler

**WebSocket Message Handler**
- **Event**: 'message'
- **Flow**:
  1. Parse JSON data
  2. Switch on message.type
  3. Execute corresponding handler
  4. Send response back to client
  5. Broadcast to other clients if needed

**Message Type Handlers**:

**'auth' Handler**
```javascript
1. Extract currentUser from message
2. Validate user object
3. If invalid: send auth_error
4. Call userManager.setUserOnline(userId, ws)
5. Send auth_success
6. Broadcast user online status
```

**'send_message' Handler**
```javascript
1. Extract chatId, content
2. Call messageManager.createMessage()
3. If success:
   - Get chat participants
   - For each participant:
     - Get WebSocket connection
     - Send 'new_message' event
     - If not sender: mark as delivered
```

**'typing' Handler**
```javascript
1. Extract chatId, isTyping
2. Get chat by ID
3. For each participant (except sender):
   - Get WebSocket connection
   - Send 'user_typing' event with user data
```

**'mark_read' Handler**
```javascript
1. Extract chatId
2. Call messageManager.markMessagesAsRead()
3. Get chat participants
4. For each participant (except sender):
   - Send 'messages_read' event
```

---

### 1.2 Frontend Modules

#### 1.2.1 QuickChatClient Class

**File**: `public/js/app.js`

**Purpose**: Main client-side application controller managing UI and WebSocket communication.

**Class Structure**:
```javascript
class QuickChatClient {
  constructor()
  init()
  switchTab(tab)
  handleLogin(e)
  handleRegister(e)
  showChatContainer()
  connectWebSocket()
  handleWebSocketMessage(data)
  loadChats()
  renderChatList()
  openNewChatModal()
  renderUsersList()
  renderGroupUsersList()
  toggleGroupMember(userId)
  createGroup()
  startChat(recipientId)
  showChat(chat, messages)
  renderMessages(messages, isGroup)
  sendMessage()
  handleNewMessage(data)
  handleTyping()
  showTypingIndicator(data)
  updateUserStatus(userId, isOnline)
  logout()
}
```

**Properties**:
- `ws`: WebSocket - Connection to server
- `currentUser`: Object - Logged in user data
- `currentChat`: Object - Active chat
- `chats`: Array - List of user's chats
- `users`: Array - List of all users
- `selectedGroupMembers`: Array - Selected users for group creation
- `typingTimeout`: Number - Timer for typing indicator

**Key Methods**:

**connectWebSocket()**
- **Logic**:
  1. Determine protocol (ws: or wss:)
  2. Create WebSocket connection to server
  3. Set up event handlers:
     - onopen: Send auth message
     - onmessage: Call handleWebSocketMessage
     - onclose: Reconnect after 3 seconds
     - onerror: Log error

**handleWebSocketMessage(data)**
- **Input**: Object data (parsed JSON)
- **Logic**:
  ```javascript
  switch(data.type) {
    case 'auth_success': loadChats(); break;
    case 'chats_list': update chats and render; break;
    case 'users_list': update users and render; break;
    case 'chat_started': open chat; break;
    case 'new_message': append message; break;
    case 'user_typing': show indicator; break;
    case 'user_status': update status; break;
  }
  ```

**sendMessage()**
- **Logic**:
  1. Get message input value
  2. Trim and validate not empty
  3. Send WebSocket message:
     ```json
     {
       "type": "send_message",
       "chatId": currentChat._id,
       "content": content
     }
     ```
  4. Clear input field

**handleTyping()**
- **Logic**:
  1. Send typing: true event
  2. Clear previous timeout
  3. Set new timeout for 2 seconds
  4. On timeout: Send typing: false event

**renderChatList()**
- **Logic**:
  1. If no chats: Show empty state
  2. For each chat:
     - Determine if group or private
     - Get display name
     - Format last message and time
     - Show unread badge if count > 0
     - Generate HTML
  3. Attach click handlers
  4. Insert into DOM

**renderMessages(messages, isGroup)**
- **Logic**:
  1. For each message:
     - Determine if sent or received
     - Get status icon
     - Show sender name if group chat
     - Format timestamp
     - Generate message HTML
  2. Insert all messages into container
  3. Scroll to bottom

---

## 2. Database Schema Details

### 2.1 User Collection

**Indexes**:
- username: unique
- email: unique

**Pre-save Hook**:
```javascript
if (password is modified) {
  hash password with bcrypt (12 salt rounds)
}
```

**Methods**:
- `comparePassword(candidatePassword)`: Compare plain text with hashed password

### 2.2 Chat Collection

**Indexes**:
- participants: 1 (for faster lookups)
- lastActivity: -1 (for sorting)

**Virtual Fields**: None

### 2.3 Message Collection

**Indexes**:
- {chatId: 1, createdAt: -1} (compound index for chat message queries)
- sender: 1 (for sender queries)

**Validation**:
- content: maxLength 5000
- messageType: enum ['text', 'image', 'file', 'system']
- status: enum ['sent', 'delivered', 'read']

---

## 3. API Endpoints Specification

### 3.1 POST /api/auth/register

**Request Body**:
```json
{
  "username": "string (min 3 chars)",
  "email": "string (valid email)",
  "password": "string (min 6 chars)"
}
```

**Response (Success - 201)**:
```json
{
  "success": true,
  "user": {
    "_id": "ObjectId",
    "username": "string",
    "email": "string",
    "status": "string",
    "profilePicture": "string"
  }
}
```

**Response (Error - 400)**:
```json
{
  "error": "Error message"
}
```

### 3.2 POST /api/auth/login

**Request Body**:
```json
{
  "email": "string",
  "password": "string"
}
```

**Response (Success - 200)**:
```json
{
  "success": true,
  "user": {
    "_id": "ObjectId",
    "username": "string",
    "email": "string",
    "status": "string",
    "profilePicture": "string",
    "isOnline": true
  }
}
```

**Response (Error - 401)**:
```json
{
  "error": "Invalid email or password"
}
```

### 3.3 GET /api/users

**Query Parameters**:
- `excludeUserId`: ObjectId (optional)

**Response (Success - 200)**:
```json
[
  {
    "_id": "ObjectId",
    "username": "string",
    "email": "string",
    "status": "string",
    "profilePicture": "string",
    "isOnline": boolean,
    "lastSeen": "Date"
  }
]
```

---

## 4. WebSocket Protocol Specification

### 4.1 Message Format

All WebSocket messages are JSON strings with the following structure:
```json
{
  "type": "string (message type)",
  "...": "additional fields based on type"
}
```

### 4.2 Client to Server Messages

**auth**
```json
{
  "type": "auth",
  "user": {
    "_id": "ObjectId",
    "username": "string",
    "email": "string"
  }
}
```

**get_users**
```json
{
  "type": "get_users"
}
```

**start_chat**
```json
{
  "type": "start_chat",
  "recipientId": "ObjectId"
}
```

**create_group**
```json
{
  "type": "create_group",
  "groupName": "string",
  "participantIds": ["ObjectId"]
}
```

**send_message**
```json
{
  "type": "send_message",
  "chatId": "ObjectId",
  "content": "string"
}
```

**typing**
```json
{
  "type": "typing",
  "chatId": "ObjectId",
  "isTyping": boolean
}
```

**mark_read**
```json
{
  "type": "mark_read",
  "chatId": "ObjectId"
}
```

### 4.3 Server to Client Messages

**auth_success**
```json
{
  "type": "auth_success",
  "user": {Object}
}
```

**chats_list**
```json
{
  "type": "chats_list",
  "chats": [Chat objects with unreadCount]
}
```

**new_message**
```json
{
  "type": "new_message",
  "message": {Message object},
  "chatId": "ObjectId"
}
```

**user_status**
```json
{
  "type": "user_status",
  "userId": "ObjectId",
  "isOnline": boolean
}
```

---

## 5. Error Handling

### 5.1 Backend Error Handling

**Pattern**:
```javascript
try {
  // Operation
} catch (error) {
  console.error('Context:', error);
  return { success: false, error: error.message };
}
```

**WebSocket Errors**:
```javascript
ws.send(JSON.stringify({
  type: 'error',
  message: error.message
}));
```

### 5.2 Frontend Error Handling

**REST API Errors**:
```javascript
if (!response.ok) {
  throw new Error(data.error);
}
errorDiv.textContent = error.message;
```

**WebSocket Reconnection**:
```javascript
ws.onclose = () => {
  setTimeout(() => {
    if (currentUser) {
      connectWebSocket();
    }
  }, 3000);
};
```

---

## 6. Utility Functions

### 6.1 Backend Utilities

**None** (Kept minimal for simplicity)

### 6.2 Frontend Utilities

**formatTime(dateStr)**
- **Purpose**: Format timestamp for display
- **Logic**:
  - If today: Show time (HH:MM)
  - If within week: Show day name
  - Else: Show date (MMM DD)

**escapeHtml(text)**
- **Purpose**: Prevent XSS attacks
- **Logic**:
  - Create div element
  - Set textContent to input
  - Return innerHTML (escaped)

---

## 7. State Management

### 7.1 Frontend State

**Storage Location**: QuickChatClient class instance

**State Variables**:
- `currentUser`: Active user session
- `currentChat`: Open chat
- `chats`: User's chat list
- `users`: All users
- `selectedGroupMembers`: Temporary group creation state

**Persistence**: 
- `currentUser` stored in localStorage as 'quickchat_user'

### 7.2 Backend State

**WebSocket Connections**:
- Stored in `UserManager.onlineUsers` Map
- Key: userId (String)
- Value: WebSocket connection

**Session Management**:
- No server-side sessions
- Each WebSocket maintains `currentUser` variable
- Cleared on disconnection

---

## 8. Performance Optimizations

### 8.1 Database Optimizations

**Indexes**:
- User: username, email (unique indexes)
- Chat: participants, lastActivity
- Message: {chatId, createdAt} compound, sender

**Query Optimization**:
- Use `.select()` to limit fields
- `.populate()` only required fields
- Limit message history to 50

### 8.2 Frontend Optimizations

**DOM Updates**:
- Batch message rendering with `.map().join()`
- Use `insertAdjacentHTML` for new messages
- Debounce typing indicator (2 second timeout)

**WebSocket**:
- Single persistent connection
- Automatic reconnection
- Event-based updates (no polling)

---

## 9. Testing Considerations

### 9.1 Unit Tests (Not Implemented)

**Backend**:
- UserManager: registerUser, loginUser
- ChatManager: createOrGetChat, createGroupChat
- MessageManager: createMessage, markMessagesAsRead

**Frontend**:
- Message rendering
- Time formatting
- HTML escaping

### 9.2 Integration Tests (Not Implemented)

- User registration → Login → Send message flow
- WebSocket connection → Authentication → Message exchange
- Group creation → Message broadcasting

### 9.3 Manual Testing

- Multiple browser tabs for simulating users
- Network throttling for connection issues
- Form validation testing
