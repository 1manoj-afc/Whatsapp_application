const User = require('./User');
const Chat = require('./Chat');
const Message = require('./Message');

module.exports = {
    User,
    Chat,
    Message
};
